import { Resend } from 'npm:resend@4.0.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface OrderData {
  name: string;
  email: string;
  phone: string;
  occasion: string;
  cake_size: string;
  flavor: string;
  design_details: string;
  event_date: string;
  budget: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const resendApiKey = Deno.env.get('RESEND_API_KEY');
    const adminEmail = Deno.env.get('ADMIN_EMAIL');

    if (!resendApiKey) {
      throw new Error('RESEND_API_KEY not configured');
    }

    if (!adminEmail) {
      throw new Error('ADMIN_EMAIL not configured');
    }

    const orderData: OrderData = await req.json();

    const resend = new Resend(resendApiKey);

    const occasionMap: Record<string, string> = {
      wedding: 'Wedding',
      birthday: 'Birthday',
      anniversary: 'Anniversary',
      graduation: 'Graduation',
      baby_shower: 'Baby Shower',
      other: 'Other',
    };

    const sizeMap: Record<string, string> = {
      small: 'Small (6-8 servings)',
      medium: 'Medium (10-15 servings)',
      large: 'Large (20-30 servings)',
      xlarge: 'Extra Large (40+ servings)',
    };

    const budgetMap: Record<string, string> = {
      under_100: 'Under $100',
      '100_200': '$100 - $200',
      '200_500': '$200 - $500',
      over_500: 'Over $500',
    };

    await resend.emails.send({
      from: 'Sweet O\'clock Orders <onboarding@resend.dev>',
      to: [adminEmail],
      subject: `New Custom Cake Order from ${orderData.name}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #0d9488; border-bottom: 2px solid #0d9488; padding-bottom: 10px;">New Custom Cake Order</h2>
          
          <div style="background-color: #f0fdfa; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="color: #0d9488; margin-top: 0;">Customer Information</h3>
            <p><strong>Name:</strong> ${orderData.name}</p>
            <p><strong>Email:</strong> <a href="mailto:${orderData.email}">${orderData.email}</a></p>
            <p><strong>Phone:</strong> <a href="tel:${orderData.phone}">${orderData.phone}</a></p>
          </div>

          <div style="background-color: #ffffff; padding: 20px; border: 1px solid #ccfbf1; border-radius: 8px; margin: 20px 0;">
            <h3 style="color: #0d9488; margin-top: 0;">Order Details</h3>
            <p><strong>Occasion:</strong> ${occasionMap[orderData.occasion] || orderData.occasion}</p>
            <p><strong>Cake Size:</strong> ${sizeMap[orderData.cake_size] || orderData.cake_size}</p>
            <p><strong>Flavor:</strong> ${orderData.flavor.charAt(0).toUpperCase() + orderData.flavor.slice(1).replace('_', ' ')}</p>
            <p><strong>Event Date:</strong> ${new Date(orderData.event_date).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
            <p><strong>Budget:</strong> ${budgetMap[orderData.budget] || orderData.budget}</p>
          </div>

          <div style="background-color: #f0fdfa; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="color: #0d9488; margin-top: 0;">Design Details & Special Requests</h3>
            <p style="white-space: pre-wrap;">${orderData.design_details}</p>
          </div>

          <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #ccfbf1; text-align: center; color: #6b7280; font-size: 12px;">
            <p>This order was submitted via Sweet O'clock website</p>
            <p>Please respond within 24 hours</p>
          </div>
        </div>
      `,
    });

    await resend.emails.send({
      from: 'Sweet O\'clock <onboarding@resend.dev>',
      to: [orderData.email],
      subject: 'We Received Your Custom Cake Order!',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #0d9488; border-bottom: 2px solid #0d9488; padding-bottom: 10px;">Thank You for Your Order!</h2>
          
          <p>Hi ${orderData.name},</p>
          
          <p>We've received your custom cake order and we're excited to create something special for you!</p>

          <div style="background-color: #f0fdfa; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="color: #0d9488; margin-top: 0;">Your Order Summary</h3>
            <p><strong>Occasion:</strong> ${occasionMap[orderData.occasion] || orderData.occasion}</p>
            <p><strong>Cake Size:</strong> ${sizeMap[orderData.cake_size] || orderData.cake_size}</p>
            <p><strong>Flavor:</strong> ${orderData.flavor.charAt(0).toUpperCase() + orderData.flavor.slice(1).replace('_', ' ')}</p>
            <p><strong>Event Date:</strong> ${new Date(orderData.event_date).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
            <p><strong>Budget:</strong> ${budgetMap[orderData.budget] || orderData.budget}</p>
          </div>

          <div style="background-color: #ffffff; padding: 20px; border: 1px solid #ccfbf1; border-radius: 8px; margin: 20px 0;">
            <h3 style="color: #0d9488; margin-top: 0;">What's Next?</h3>
            <ul style="line-height: 1.8;">
              <li>Our team will review your design details and requirements</li>
              <li>We'll contact you within 24 hours with a quote and design consultation</li>
              <li>Once approved, we'll confirm your order and begin creating your custom cake</li>
            </ul>
          </div>

          <p>If you have any questions in the meantime, feel free to reply to this email or give us a call at your provided phone number.</p>

          <p style="margin-top: 30px;">Best regards,<br><strong>The Sweet O'clock Team</strong></p>

          <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #ccfbf1; text-align: center; color: #6b7280; font-size: 12px;">
            <p>Sweet O'clock - Creating Sweet Memories</p>
          </div>
        </div>
      `,
    });

    return new Response(
      JSON.stringify({ success: true, message: 'Notifications sent successfully' }),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error) {
    console.error('Error sending notification:', error);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});