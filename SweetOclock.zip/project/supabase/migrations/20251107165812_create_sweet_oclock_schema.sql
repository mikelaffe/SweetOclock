/*
  # Sweet O'clock Database Schema

  1. New Tables
    - `cakes`
      - `id` (uuid, primary key)
      - `name` (text) - Name of the cake
      - `description` (text) - Description of the cake
      - `image_url` (text) - URL to cake image
      - `category` (text) - Category (featured, wedding, birthday, etc.)
      - `price` (numeric) - Base price
      - `created_at` (timestamptz)
    
    - `testimonials`
      - `id` (uuid, primary key)
      - `client_name` (text) - Name of the client
      - `testimonial` (text) - The testimonial text
      - `rating` (integer) - Rating out of 5
      - `created_at` (timestamptz)
    
    - `custom_orders`
      - `id` (uuid, primary key)
      - `name` (text) - Customer name
      - `email` (text) - Customer email
      - `phone` (text) - Customer phone
      - `occasion` (text) - Occasion type
      - `cake_size` (text) - Size of the cake
      - `flavor` (text) - Cake flavor
      - `design_details` (text) - Design specifications
      - `event_date` (date) - Date of the event
      - `budget` (text) - Budget range
      - `status` (text) - Order status (pending, confirmed, completed)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Public read access for cakes and testimonials
    - Authenticated insert for custom_orders
*/

-- Create cakes table
CREATE TABLE IF NOT EXISTS cakes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text NOT NULL,
  image_url text NOT NULL,
  category text NOT NULL DEFAULT 'general',
  price numeric(10,2) DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE cakes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view cakes"
  ON cakes FOR SELECT
  TO public
  USING (true);

-- Create testimonials table
CREATE TABLE IF NOT EXISTS testimonials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_name text NOT NULL,
  testimonial text NOT NULL,
  rating integer NOT NULL DEFAULT 5 CHECK (rating >= 1 AND rating <= 5),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE testimonials ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view testimonials"
  ON testimonials FOR SELECT
  TO public
  USING (true);

-- Create custom_orders table
CREATE TABLE IF NOT EXISTS custom_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  occasion text NOT NULL,
  cake_size text NOT NULL,
  flavor text NOT NULL,
  design_details text NOT NULL,
  event_date date NOT NULL,
  budget text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE custom_orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can submit custom orders"
  ON custom_orders FOR INSERT
  TO public
  WITH CHECK (true);