import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-white border-t border-gray-100 mt-20">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          <div>
            <img
              src="/WhatsApp Image 2025-11-08 at 19.03.17_57b67ea7.jpg"
              alt="Sweet O'clock"
              className="h-24"
            />
            <p className="text-sm text-gray-600">Making life a little sweeter, since 2023.</p>
          </div>

          <div>
            <h3 className="font-medium text-gray-900 mb-4">Quick Links</h3>
            <div className="space-y-2">
              <Link to="/cakes" className="block text-sm text-gray-600 hover:text-teal-600 transition-colors">
                Our Cakes
              </Link>
              <Link to="/custom-orders" className="block text-sm text-gray-600 hover:text-teal-600 transition-colors">
                Custom Orders
              </Link>
              <Link to="/about" className="block text-sm text-gray-600 hover:text-teal-600 transition-colors">
                About Us
              </Link>
            </div>
          </div>

          <div>
            <h3 className="font-medium text-gray-900 mb-4">Contact Us</h3>
            <div className="space-y-2 text-sm text-gray-600">
              <p>Zouk Mkayel</p>
              <p>Naqqache Next To Wooden Bakery</p>
              <p>+961 71 568 637</p>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-100 mt-12 pt-8">
          <div className="text-center text-sm text-gray-500 mb-6">
            © 2024 Sweet O'clock. All Rights Reserved.
          </div>
          <div className="flex items-center justify-center gap-3">
            <span className="text-sm text-gray-500">Website built by</span>
            <a
              href="https://cresvia.co"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 hover:opacity-80 transition-opacity"
            >
              <img
                src="/WhatsApp Image 2025-11-06 at 18.52.53_33f5267b.jpg"
                alt="Cresvia Logo"
                className="h-16"
              />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
