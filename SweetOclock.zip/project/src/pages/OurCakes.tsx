import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

interface Cake {
  id: string;
  name: string;
  description: string;
  image_url: string;
  category: string;
  price: number;
}

export default function OurCakes() {
  const [cakes, setCakes] = useState<Cake[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  useEffect(() => {
    loadCakes();
  }, [selectedCategory]);

  const loadCakes = async () => {
    let query = supabase.from('cakes').select('*');

    if (selectedCategory !== 'all') {
      query = query.eq('category', selectedCategory);
    }

    const { data } = await query;
    if (data) setCakes(data);
  };

  const categories = [
    { value: 'all', label: 'All Cakes' },
    { value: 'featured', label: 'Featured' },
    { value: 'wedding', label: 'Wedding' },
    { value: 'birthday', label: 'Birthday' },
    { value: 'celebration', label: 'Celebration' },
  ];

  return (
    <div className="pt-20">
      <section className="bg-gradient-to-r from-teal-600 to-teal-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h1 className="text-5xl font-light italic mb-4">Our Cakes</h1>
          <p className="text-xl text-teal-50">Discover our delicious creations</p>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-6 py-12">
        <div className="flex justify-center gap-4 mb-12 flex-wrap">
          {categories.map((category) => (
            <button
              key={category.value}
              onClick={() => setSelectedCategory(category.value)}
              className={`px-6 py-2 rounded-full transition-colors ${
                selectedCategory === category.value
                  ? 'bg-teal-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {category.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {cakes.map((cake) => (
            <div
              key={cake.id}
              className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow group"
            >
              <div className="relative overflow-hidden">
                <img
                  src={cake.image_url}
                  alt={cake.name}
                  className="w-full h-72 object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-xl font-medium text-gray-900">{cake.name}</h3>
                  {cake.price > 0 && (
                    <span className="text-teal-600 font-medium">${cake.price}</span>
                  )}
                </div>
                <p className="text-gray-600 text-sm mb-4">{cake.description}</p>
                <span className="inline-block text-xs text-teal-600 bg-teal-50 px-3 py-1 rounded-full">
                  {cake.category}
                </span>
              </div>
            </div>
          ))}
        </div>

        {cakes.length === 0 && (
          <div className="text-center py-16">
            <p className="text-gray-500 text-lg">No cakes found in this category.</p>
          </div>
        )}
      </section>
    </div>
  );
}
