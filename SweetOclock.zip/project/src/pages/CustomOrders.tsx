import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { CheckCircle, Cake } from 'lucide-react';

export default function CustomOrders() {
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    occasion: '',
    cake_size: '',
    flavor: '',
    design_details: '',
    event_date: '',
    budget: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const { error } = await supabase.from('custom_orders').insert([formData]);

    if (!error) {
      try {
        const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-order-notification`;
        await fetch(apiUrl, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(formData),
        });
      } catch (notificationError) {
        console.error('Failed to send notification:', notificationError);
      }

      setSubmitted(true);
      setFormData({
        name: '',
        email: '',
        phone: '',
        occasion: '',
        cake_size: '',
        flavor: '',
        design_details: '',
        event_date: '',
        budget: '',
      });
    }

    setLoading(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  if (submitted) {
    return (
      <div className="pt-20 min-h-screen flex items-center justify-center bg-gradient-to-b from-teal-50 to-white">
        <div className="max-w-md mx-auto px-6 text-center">
          <CheckCircle className="w-20 h-20 text-teal-600 mx-auto mb-6" />
          <h2 className="text-3xl font-light text-gray-900 mb-4">Order Submitted!</h2>
          <p className="text-gray-600 mb-8">
            Thank you for your custom order request. We'll review your details and get back to you within 24 hours.
          </p>
          <button
            onClick={() => setSubmitted(false)}
            className="bg-teal-600 text-white px-8 py-3 rounded-full hover:bg-teal-700 transition-colors"
          >
            Submit Another Order
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-20">
      <section className="bg-gradient-to-r from-teal-600 to-teal-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <Cake className="w-16 h-16 mx-auto mb-4" />
          <h1 className="text-5xl font-light italic mb-4">Custom Orders</h1>
          <p className="text-xl text-teal-50">Let's create your dream cake together</p>
        </div>
      </section>

      <section className="max-w-3xl mx-auto px-6 py-12">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                  Your Name *
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  required
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-600 focus:border-transparent outline-none transition"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                  Email Address *
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  required
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-600 focus:border-transparent outline-none transition"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">
                  Phone Number *
                </label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  required
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-600 focus:border-transparent outline-none transition"
                />
              </div>

              <div>
                <label htmlFor="occasion" className="block text-sm font-medium text-gray-700 mb-2">
                  Occasion *
                </label>
                <select
                  id="occasion"
                  name="occasion"
                  required
                  value={formData.occasion}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-600 focus:border-transparent outline-none transition"
                >
                  <option value="">Select an occasion</option>
                  <option value="wedding">Wedding</option>
                  <option value="birthday">Birthday</option>
                  <option value="anniversary">Anniversary</option>
                  <option value="graduation">Graduation</option>
                  <option value="baby_shower">Baby Shower</option>
                  <option value="other">Other</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="cake_size" className="block text-sm font-medium text-gray-700 mb-2">
                  Cake Size *
                </label>
                <select
                  id="cake_size"
                  name="cake_size"
                  required
                  value={formData.cake_size}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-600 focus:border-transparent outline-none transition"
                >
                  <option value="">Select size</option>
                  <option value="small">Small (6-8 servings)</option>
                  <option value="medium">Medium (10-15 servings)</option>
                  <option value="large">Large (20-30 servings)</option>
                  <option value="xlarge">Extra Large (40+ servings)</option>
                </select>
              </div>

              <div>
                <label htmlFor="flavor" className="block text-sm font-medium text-gray-700 mb-2">
                  Flavor *
                </label>
                <select
                  id="flavor"
                  name="flavor"
                  required
                  value={formData.flavor}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-600 focus:border-transparent outline-none transition"
                >
                  <option value="">Select flavor</option>
                  <option value="vanilla">Vanilla</option>
                  <option value="chocolate">Chocolate</option>
                  <option value="red_velvet">Red Velvet</option>
                  <option value="lemon">Lemon</option>
                  <option value="carrot">Carrot</option>
                  <option value="custom">Custom Flavor</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="event_date" className="block text-sm font-medium text-gray-700 mb-2">
                  Event Date *
                </label>
                <input
                  type="date"
                  id="event_date"
                  name="event_date"
                  required
                  value={formData.event_date}
                  onChange={handleChange}
                  min={new Date().toISOString().split('T')[0]}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-600 focus:border-transparent outline-none transition"
                />
              </div>

              <div>
                <label htmlFor="budget" className="block text-sm font-medium text-gray-700 mb-2">
                  Budget Range *
                </label>
                <select
                  id="budget"
                  name="budget"
                  required
                  value={formData.budget}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-600 focus:border-transparent outline-none transition"
                >
                  <option value="">Select budget</option>
                  <option value="under_100">Under $100</option>
                  <option value="100_200">$100 - $200</option>
                  <option value="200_500">$200 - $500</option>
                  <option value="over_500">Over $500</option>
                </select>
              </div>
            </div>

            <div>
              <label htmlFor="design_details" className="block text-sm font-medium text-gray-700 mb-2">
                Design Details & Special Requests *
              </label>
              <textarea
                id="design_details"
                name="design_details"
                required
                rows={5}
                value={formData.design_details}
                onChange={handleChange}
                placeholder="Tell us about your vision... colors, themes, decorations, dietary restrictions, etc."
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-600 focus:border-transparent outline-none transition resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-teal-600 text-white py-3 rounded-lg hover:bg-teal-700 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Submitting...' : 'Submit Custom Order Request'}
            </button>
          </form>
        </div>

        <div className="mt-8 text-center text-sm text-gray-600">
          <p>We typically respond within 24 hours with a quote and design consultation.</p>
        </div>
      </section>
    </div>
  );
}
