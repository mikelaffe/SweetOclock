import { Heart, Award, Users, Clock } from 'lucide-react';

export default function About() {
  return (
    <div className="pt-20">
      <section className="bg-gradient-to-r from-teal-600 to-teal-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h1 className="text-5xl font-light italic mb-4">About Us</h1>
          <p className="text-xl text-teal-50">Our story, our passion, our commitment</p>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
          <div>
            <h2 className="text-4xl font-light text-teal-600 italic mb-6">Our Story</h2>
            <div className="space-y-4 text-gray-700 leading-relaxed">
              <p>
                Sweet O'clock was born from a simple belief: every celebration deserves a cake that's as unique and special as the moment itself.
              </p>
              <p>
                Founded in 2023, we started as a small home bakery with a passion for creating beautiful, delicious cakes. Today, we're proud to serve our community with custom creations that bring joy to every occasion.
              </p>
              <p>
                Our team of talented pastry chefs combines traditional baking techniques with modern design trends to create cakes that are not just desserts, but edible works of art.
              </p>
            </div>
          </div>

          <div className="relative">
            <div className="rounded-lg overflow-hidden shadow-xl">
              <img
                src="https://images.pexels.com/photos/1070850/pexels-photo-1070850.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Bakery interior"
                className="w-full h-[400px] object-cover"
              />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          <div className="text-center p-6">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-teal-100 rounded-full mb-4">
              <Heart className="w-8 h-8 text-teal-600" />
            </div>
            <h3 className="text-xl font-medium text-gray-900 mb-2">Made with Love</h3>
            <p className="text-gray-600 text-sm">
              Every cake is crafted with care and attention to detail
            </p>
          </div>

          <div className="text-center p-6">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-teal-100 rounded-full mb-4">
              <Award className="w-8 h-8 text-teal-600" />
            </div>
            <h3 className="text-xl font-medium text-gray-900 mb-2">Premium Quality</h3>
            <p className="text-gray-600 text-sm">
              We use only the finest ingredients for exceptional taste
            </p>
          </div>

          <div className="text-center p-6">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-teal-100 rounded-full mb-4">
              <Users className="w-8 h-8 text-teal-600" />
            </div>
            <h3 className="text-xl font-medium text-gray-900 mb-2">Expert Team</h3>
            <p className="text-gray-600 text-sm">
              Talented pastry chefs with years of experience
            </p>
          </div>

          <div className="text-center p-6">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-teal-100 rounded-full mb-4">
              <Clock className="w-8 h-8 text-teal-600" />
            </div>
            <h3 className="text-xl font-medium text-gray-900 mb-2">Since 2023</h3>
            <p className="text-gray-600 text-sm">
              Making life sweeter one cake at a time
            </p>
          </div>
        </div>
      </section>

      <section className="bg-teal-50 py-16">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-4xl font-light text-teal-600 italic mb-6">Our Philosophy</h2>
          <p className="text-gray-700 text-lg leading-relaxed mb-8">
            We believe that a cake should be more than just a dessert. It should be a centerpiece, a conversation starter, and a memory maker. That's why we work closely with each client to understand their vision and bring it to life with precision and artistry.
          </p>
          <p className="text-gray-700 text-lg leading-relaxed">
            From classic elegance to bold contemporary designs, we're committed to creating cakes that not only look stunning but taste absolutely divine. Because at Sweet O'clock, time is always sweet.
          </p>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-6 py-16">
        <div className="bg-gradient-to-r from-teal-600 to-teal-700 rounded-2xl p-12 text-center text-white">
          <h2 className="text-3xl font-light italic mb-4">Ready to Create Something Sweet?</h2>
          <p className="text-teal-50 mb-6 text-lg">
            Let's work together to make your dream cake a reality
          </p>
          <a
            href="/custom-orders"
            className="inline-block bg-white text-teal-600 px-8 py-3 rounded-full hover:bg-teal-50 transition-colors font-medium"
          >
            Start Your Order
          </a>
        </div>
      </section>
    </div>
  );
}
