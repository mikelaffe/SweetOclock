import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Star } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Cake {
  id: string;
  name: string;
  description: string;
  image_url: string;
  category: string;
}

interface Testimonial {
  id: string;
  client_name: string;
  testimonial: string;
  rating: number;
}

export default function Home() {
  const [featuredCakes, setFeaturedCakes] = useState<Cake[]>([]);
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);

  useEffect(() => {
    loadFeaturedCakes();
    loadTestimonials();
  }, []);

  const loadFeaturedCakes = async () => {
    const { data } = await supabase
      .from('cakes')
      .select('*')
      .eq('category', 'featured')
      .limit(3);
    if (data) setFeaturedCakes(data);
  };

  const loadTestimonials = async () => {
    const { data } = await supabase
      .from('testimonials')
      .select('*')
      .limit(3);
    if (data) setTestimonials(data);
  };

  return (
    <div className="pt-20">
      <section className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-6xl font-light text-teal-600 italic mb-6">
              Time is Sweet
            </h1>
            <p className="text-gray-700 text-lg mb-8 leading-relaxed">
              Crafting unforgettable moments, one slice at a time. Welcome to Sweet O'clock, where your dream cakes come to life.
            </p>
            <Link
              to="/custom-orders"
              className="inline-block bg-teal-600 text-white px-8 py-3 rounded-full hover:bg-teal-700 transition-colors"
            >
              Create Your Custom Cake
            </Link>
          </div>

          <div className="relative">
            <div className="bg-teal-600 rounded-lg overflow-hidden shadow-2xl">
              <img
                src="https://images.pexels.com/photos/1055272/pexels-photo-1055272.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Beautiful turquoise birthday cake"
                className="w-full h-[500px] object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="bg-gradient-to-b from-white to-gray-50 py-20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-light text-teal-600 italic mb-4">
              Our Featured Creations
            </h2>
            <p className="text-gray-600">A taste of what we can do for you.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredCakes.map((cake) => (
              <div key={cake.id} className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
                <img
                  src={cake.image_url}
                  alt={cake.name}
                  className="w-full h-64 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-medium text-gray-900 mb-2">{cake.name}</h3>
                  <p className="text-gray-600 text-sm">{cake.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-teal-50 py-20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-light text-teal-600 italic mb-4">
              Sweet Words From Our Clients
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial) => (
              <div key={testimonial.id} className="bg-white rounded-lg p-8 shadow-md">
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-gray-700 italic mb-4">"{testimonial.testimonial}"</p>
                <p className="text-gray-900 font-medium">— {testimonial.client_name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-5xl font-light text-teal-600 italic mb-6">
            Have a Sweet Idea?
          </h2>
          <p className="text-gray-700 text-lg mb-8 leading-relaxed">
            Let us bring your vision to life. From elegant weddings to whimsical birthdays,
            we specialize in creating custom cakes that taste as incredible as they look.
          </p>
          <Link
            to="/custom-orders"
            className="inline-block bg-teal-600 text-white px-8 py-3 rounded-full hover:bg-teal-700 transition-colors"
          >
            Place Your Custom Order
          </Link>
        </div>
      </section>
    </div>
  );
}
